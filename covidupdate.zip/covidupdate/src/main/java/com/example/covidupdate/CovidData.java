package com.example.covidupdate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Arrays;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CovidData {

  private Result result[];

  private String province_name;



    //getter setter
    public Result[] getResult() {
        return result;
    }

    public void setResult(Result[] result) {
        this.result = result;
    }

    public String getProvince_name() {
        return province_name;
    }

    public void setProvince_name(String province_name) {
        this.province_name = province_name;
    }

    //constructor
    public CovidData() {
    }

    public CovidData(Result[] result, String province_name) {
        this.result = result;
        this.province_name = province_name;
    }


//toString


    @Override
    public String toString() {
        return "CovidData{" +
                "result=" + Arrays.toString(result) +
                ", province_name='" + province_name + '\'' +
                '}';
    }
}

package com.example.covidupdate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
public class CovidDataController {

    @GetMapping("/covid_case")  //http://localhost:9000/covid_case?province_name=ภูเก็ต
    String getDataByProvince2(@RequestParam("province_name") String provinceName) throws JsonProcessingException {
        RestTemplate rt = new RestTemplate();
        String url = "https://covid19.ddc.moph.go.th/api/Cases/today-cases-by-provinces";
        ResponseEntity<String> res = rt.getForEntity(url, String.class);
        System.out.println("status code --> " + res.getStatusCode());
        System.out.println("Response body: " + res.getBody());
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(res.getBody());
        //ลิสต์ของโหนด ที่ชื่อ เคสรายจังหวัด มีค่าเท่ากับ คำสั่งหาโหนดที่มีค่า ตามชื่อ จังหวัดนั้นๆ
        List<JsonNode> casesByProvince = root.findValues("province");
        String result = "";
        for (int i = 0; i < casesByProvince.size(); i++) {
            if (casesByProvince.get(i).toString().equals("\"" + provinceName + "\"")) { // ถ้าค่าที่รับมาจาก พารามีเตอร์บน url มีค่าเท่ากับ ลิสต์ของโหนดที่มีชื่อตามชื่อจังหวัดนั้น ก็กำหนด ให้แสดงค่าข้อมูลต่างๆที่จัดเรียงใน result
                result = root.get(i) .toString()  ;
                break;
            }
        }
        return result;
    }

    @GetMapping("/covid")  //http://localhost:9000/covid?province_name=เชียงใหม่
    String getDataByProvince(@RequestParam("province_name") String provinceName) throws JsonProcessingException {
        RestTemplate rt = new RestTemplate();
        String url = "https://covid19.ddc.moph.go.th/api/Cases/today-cases-by-provinces";
        ResponseEntity<String> res = rt.getForEntity(url, String.class);
        System.out.println("status code --> " + res.getStatusCode());
        System.out.println("Response body: " + res.getBody());
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(res.getBody());
        //ลิสต์ของโหนด ที่ชื่อ เคสรายจังหวัด มีค่าเท่ากับ คำสั่งหาโหนดที่มีค่า ตามชื่อ จังหวัดนั้นๆ
        List<JsonNode> casesByProvince = root.findValues("province");
        List<JsonNode> year = root.findValues("year");
        List<JsonNode> weekNum = root.findValues("weeknum");
        List<JsonNode> casesByProvinceToday = root.findValues("new_case");
        List<JsonNode> casesByProvinceTotal = root.findValues("total_case");
        List<JsonNode> casesByProvinceNew = root.findValues("new_case_excludeabroad");
        List<JsonNode> totalCaseExcludeAbroad = root.findValues("total_case_excludeabroad");
        List<JsonNode> newDeath = root.findValues("new_death");
        List<JsonNode> totalDeath = root.findValues("total_death");
        List<JsonNode> updateDate = root.findValues("update_date");
        String result = "";
        for (int i = 0; i < casesByProvince.size(); i++) {
            if (casesByProvince.get(i).toString().equals("\"" + provinceName + "\"")) { // ถ้าค่าที่รับมาจาก พารามีเตอร์บน url มีค่าเท่ากับ ลิสต์ของโหนดที่มีชื่อตามชื่อจังหวัดนั้น ก็กำหนด ให้แสดงค่าข้อมูลต่างๆที่จัดเรียงใน result
                result = "  Year: " + year.get(i).asText() + " Week Number : " + weekNum.get(i).asText()
                +        " , Today's new cases in " + provinceName +  " : " + casesByProvinceToday.get(i).asText()
                +        " , Total cases : " + casesByProvinceTotal.get(i).asText() + " , New Case exclude abroad " + casesByProvinceNew.get(i).asText()
                +        " , Total cases exclude abroad : " + totalCaseExcludeAbroad.get(i).asText()
                +        " , New Death : "  + newDeath.get(i).asText() + " , Total Death :  " + totalDeath.get(i).asText()
                +        " , Update Date : " + updateDate.get(i).asText();     //แปลงค่าเป็น text และ get(i) เอาเฉพาะค่าของข้อมูลในตำแหน่งนั้นๆออกมาแสดงผล                           ;
                break;
            }
        }
        return result;
    }

        @GetMapping("/covid19") //  http://localhost:9000/covid19
    String getAllData() throws JsonProcessingException {
        RestTemplate rt = new RestTemplate();
        String url = "https://covid19.ddc.moph.go.th/api/Cases/today-cases-by-provinces";
        ResponseEntity<String> res = rt.getForEntity(url, String.class); // store data response in clas string
        System.out.println("status code --> " + res.getStatusCode());
        System.out.println("Response body: " + res.getBody()); //จุดสังเกตุ! res.getBody() มีค่าลิสต์ข้อมูลของทุกจังหวัด
        ObjectMapper mapper = new ObjectMapper();
        JsonNode root = mapper.readTree(res.getBody()); //root เก็บค่าข้อมูลที่มีค่าลิสต์ข้อมูลของทุกจังหวัดในรูปแบบ json body ไว้
        //JsonNode name = root.path("result").path("[0].update_date");
        return root.toString(); //นำมาแปลงเป็นสตริงแล้วรีเทิรน์ค่าออกมาทางหน้าเว็บ
    }
}

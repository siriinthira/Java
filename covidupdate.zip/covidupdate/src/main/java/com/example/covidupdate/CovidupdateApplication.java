package com.example.covidupdate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CovidupdateApplication {

    public static void main(String[] args) {

        SpringApplication.run(CovidupdateApplication.class, args);
    }

}

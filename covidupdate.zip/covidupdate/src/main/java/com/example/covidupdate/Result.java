package com.example.covidupdate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Result {

    private String year;
    private Integer weeknum;
    private String province;
    private Integer new_case;
    private Integer total_case;
    private Integer new_case_excludeabroad;
    private Integer total_case_excludeabroad;
    private Integer new_death;
    private Integer total_death;
    private String update_date;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public Integer getWeeknum() {
        return weeknum;
    }

    public void setWeeknum(Integer weeknum) {
        this.weeknum = weeknum;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public Integer getNew_case() {
        return new_case;
    }

    public void setNew_case(Integer new_case) {
        this.new_case = new_case;
    }

    public Integer getTotal_case() {
        return total_case;
    }

    public void setTotal_case(Integer total_case) {
        this.total_case = total_case;
    }

    public Integer getNew_case_excludeabroad() {
        return new_case_excludeabroad;
    }

    public void setNew_case_excludeabroad(Integer new_case_excludeabroad) {
        this.new_case_excludeabroad = new_case_excludeabroad;
    }

    public Integer getTotal_case_excludeabroad() {
        return total_case_excludeabroad;
    }

    public void setTotal_case_excludeabroad(Integer total_case_excludeabroad) {
        this.total_case_excludeabroad = total_case_excludeabroad;
    }

    public Integer getNew_death() {
        return new_death;
    }

    public void setNew_death(Integer new_death) {
        this.new_death = new_death;
    }

    public Integer getTotal_death() {
        return total_death;
    }

    public void setTotal_death(Integer total_death) {
        this.total_death = total_death;
    }

    public String getUpdate_date() {
        return update_date;
    }

    public void setUpdate_date(String update_date) {
        this.update_date = update_date;
    }

    @Override
    public String toString() {
        return "Result{" +
                "year='" + year + '\'' +
                ", weeknum=" + weeknum +
                ", province='" + province + '\'' +
                ", new_case=" + new_case +
                ", total_case=" + total_case +
                ", new_case_excludeabroad=" + new_case_excludeabroad +
                ", total_case_excludeabroad=" + total_case_excludeabroad +
                ", new_death=" + new_death +
                ", total_death=" + total_death +
                ", update_date='" + update_date + '\'' +
                '}';
    }


}

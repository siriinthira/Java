package com.example.covidupdate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CovidupdateApplicationTests {

    @Test
    void contextLoads() {
    }

}
